package com.firebow.util;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Silent rotation với smoothing — bypass AimModulo360.
 *
 * AimModulo360 detect snap rotation (thay đổi lớn trong 1 tick).
 * Fix: spread rotation qua SMOOTH_TICKS tick với cubic ease-out.
 *
 * tick N   : setPendingTarget → khởi smoothing từ yaw hiện tại
 * tick N..N+SMOOTH_TICKS: applyBeforeSync → tăng dần yaw mỗi tick
 * tick N+SMOOTH_TICKS: isRotationReady() = true → executeRail → interact
 */
public final class RotationUtil {
    private RotationUtil() {}

    // Target
    private static volatile Vec3d  pendingHitVec = null;
    private static volatile float  savedYaw      = 0f;
    private static volatile float  savedPitch    = 0f;
    private static volatile boolean applied      = false;

    // Smoothing
    private static float  smoothStartYaw   = Float.NaN;
    private static float  smoothStartPitch = Float.NaN;
    private static float  targetYaw        = Float.NaN;
    private static float  targetPitch      = Float.NaN;
    private static int    smoothTick       = 0;
    // 3 tick = 150ms — đủ nhanh cho HT1, đủ chậm để qua AimModulo360
    private static final int SMOOTH_TICKS  = 3;

    public static void setPendingTarget(ClientPlayerEntity player, Vec3d hitVec) {
        savedYaw        = player.getYaw();
        savedPitch      = player.getPitch();
        pendingHitVec   = hitVec;
        applied         = false;
        // Init smooth từ góc hiện tại
        smoothStartYaw   = player.getYaw();
        smoothStartPitch = player.getPitch();
        smoothTick       = 0;
        targetYaw        = Float.NaN;
        targetPitch      = Float.NaN;
    }

    public static boolean hasPendingTarget() { return pendingHitVec != null; }
    public static boolean wasApplied()       { return applied && pendingHitVec != null; }

    /**
     * Gọi từ beforeSync mỗi tick — apply rotation từng bước.
     * Cubic ease-out: nhanh lúc đầu, chậm lúc cuối → không bị detect snap.
     */
    public static boolean applyBeforeSync(ClientPlayerEntity player) {
        if (pendingHitVec == null) return false;

        // Tính target từ eyePos tick này
        float[] rot = calcRotationFromEye(player.getEyePos(), pendingHitVec);
        targetYaw   = rot[0];
        targetPitch = rot[1];

        smoothTick = Math.min(smoothTick + 1, SMOOTH_TICKS);
        float t    = (float) smoothTick / SMOOTH_TICKS;
        // Cubic ease-out: f(t) = 1 - (1-t)^3
        float ease = 1f - (1f - t) * (1f - t) * (1f - t);

        // Wrap delta để tránh quay sai chiều (ví dụ 350° → 10°)
        float dyaw   = wrapDegrees(targetYaw   - smoothStartYaw);
        float dpitch = targetPitch - smoothStartPitch;

        float currentYaw   = smoothStartYaw   + dyaw   * ease;
        float currentPitch = smoothStartPitch + dpitch * ease;

        applyRaw(player, new float[]{ currentYaw, currentPitch });
        applied = true;
        return true;
    }

    /** true khi đã smooth đủ SMOOTH_TICKS → sẵn sàng interact */
    public static boolean isRotationReady() {
        return smoothTick >= SMOOTH_TICKS && !Float.isNaN(targetYaw);
    }

    public static void restoreAfterInteract(ClientPlayerEntity player) {
        pendingHitVec  = null;
        applied        = false;
        smoothTick     = 0;
        targetYaw      = Float.NaN;
        targetPitch    = Float.NaN;
        if (player != null) applyRaw(player, new float[]{ savedYaw, savedPitch });
    }

    public static void abort(ClientPlayerEntity player) {
        if (pendingHitVec != null) restoreAfterInteract(player);
        else applied = false;
    }

    public static void endOfTick() { applied = false; }

    // ─── KeyboardInputMixin ──────────────────────────────────────────────────

    public static float[] getPendingRot(ClientPlayerEntity player) {
        if (pendingHitVec == null) return null;
        return calcRotationFromEye(player.getEyePos(), pendingHitVec);
    }

    // ─── Math utils ──────────────────────────────────────────────────────────

    public static float[] calcRotation(ClientPlayerEntity player, Vec3d target) {
        return calcRotationFromEye(player.getEyePos(), target);
    }

    public static float[] calcRotationFromEye(Vec3d eye, Vec3d target) {
        double dx   = target.x - eye.x;
        double dy   = target.y - eye.y;
        double dz   = target.z - eye.z;
        double dist = Math.sqrt(dx * dx + dz * dz);
        float  yaw  = (float)  Math.toDegrees(Math.atan2(-dx, dz));
        float  pitch= (float) -Math.toDegrees(Math.atan2(dy, dist));
        return new float[]{ yaw, pitch };
    }

    public static Vec3d calcHitVec(BlockPos pos, Direction face) {
        return Vec3d.ofCenter(pos).add(
            face.getOffsetX() * 0.4999,
            face.getOffsetY() * 0.4999,
            face.getOffsetZ() * 0.4999
        );
    }

    /** Force apply target rotation ngay — dùng khi tên quá nhanh, không có thời gian smooth. */
    public static void forceApplyNow(ClientPlayerEntity player) {
        if (pendingHitVec == null || player == null) return;
        float[] rot = calcRotationFromEye(player.getEyePos(), pendingHitVec);
        smoothTick = SMOOTH_TICKS; // mark as ready
        applyRaw(player, rot);
        applied = true;
    }

    private static float wrapDegrees(float deg) {
        deg = deg % 360f;
        if (deg >= 180f)  deg -= 360f;
        if (deg < -180f)  deg += 360f;
        return deg;
    }

    public static void applyRaw(ClientPlayerEntity player, float[] rot) {
        player.setYaw(rot[0]);
        player.setPitch(rot[1]);
        player.headYaw = rot[0];
        player.bodyYaw = rot[0];
    }
}
